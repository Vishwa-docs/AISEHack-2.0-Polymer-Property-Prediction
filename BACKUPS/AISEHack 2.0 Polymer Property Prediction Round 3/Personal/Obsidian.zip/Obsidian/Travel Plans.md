+ Packing List
    + Vibuthi and Yellow Rice
    + Shoes, Toiletries
+ Flight Tickets and Checking In (Pre Flight)
	+ Aadhar Xerox, Flight Ticket Xerox
	+ Dolo
+ Call Hotel
+ Plan Taxi
+ Check HSBC + Timings for Tomrrow

+ Note Down Costs
+ Retro Claim (Post Flight)
    + https://www.goindigo.in/loyalty/dashboard/retro-claim.html