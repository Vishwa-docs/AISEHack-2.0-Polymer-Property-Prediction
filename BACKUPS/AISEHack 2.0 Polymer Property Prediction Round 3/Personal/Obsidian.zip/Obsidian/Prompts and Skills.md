Anti AI Writing Skills

https://mail.google.com/mail/u/0/#inbox/FMfcgzQhWBlfZfDLHwbqgvGRqkmDjKTm
# Recreation Prompt

Deliver to the user's Mac final_submissions/ ONE completely standalone .py submission file that is written as REAL Python functions/classes only — NO TOOL_SOURCES dicts, NO VARIANT_CONFIGS/RECIPE JSON blobs, NO sha256/hash computation anywhere in the file, NO base64, NO tar/gzip, NO embedded archives, NO reference to previous runs, previous bundles, experiment records, or any precomputed CSV at runtime. The file takes ONLY the official competition dataset (train.csv/test.csv/PI1M.csv), regenerates every artifact (features, models, OOF, base compound chain, final arms) as actual Python functions called from a main() in dependency order, with every configuration value (weights, alphas, damp, spread scale, medians, seeds) written as literal Python constants in the file, and writes the 4940-row submission.csv that scores >= 0.9041. Someone with only the .py + official dataset must reproduce the score. No oracle/assisted wording anywhere. (2) The generated submission.csv. (3) Updated final_submissions/README.md with the verified score, architecture, and all hyperparameters — no oracle word, no hash listings. DO NOT run again until the user has verified and approved the file structure.

No intermediate csvs from previous runs can be called and used. If any is there like that, you need to trace them, find the code that generated them and then put that code in the py file. The blends also, same thing. We need to first generate the intermediate CSVs in the py file itself, and then use those for remaining, until we get the final 0.904 score.

Continue this trace and give me the py file for verification first, then you can begin testing adn verification of it after my approval.

# New Experiment Scaffolding
Read AGENTS.md and CONTEXT.md for context of the event and what we are trying to do here, and how to connect to GPU laptop.

Now in score_discrepancy/, there is another AGENTS.md. The goal for us is to maximize the R2 score against the final_oracle.csv. So far, if you read the files, we have achieved only a score of 0.891 on the private leaderboard (Or 0.900 Oracle Score). This is where you come in.

I need you to create a file called PLAN.md and put it inside the score_discrepancy/ folder. The goal is to run a few experiments, and reach an oracle score of 0.935 at least. 

To help you, there are a few things given : 

1. Phase 2 runs and score (These are not exactly accuract because the oracle score is higher than needed, but it can give you an idea). To access them, read AGENTS.md on the repo root to find our some experiments done. Some are also there in TRIALS.md file

2. 150 Experiments : In GPU Laptop, /Desktop/r3_runtime/Phase_2/ : I ran about a 150 experiments. There are some results here as well

3. score_discrepancy/NEW_EXPERIMENTS.md : I had asked other agents to give me a plan for a few experiments.

Apart from this, the organizers have given a new dataset for this round, which has 5.97 million unique molecular structures (Dataset/smile_r3.csv) which can be used for things like 

Self-supervised or unsupervised pretraining of molecular representations

SMILES-based representation learning

Feature enrichment and molecular embedding generation

Transfer learning to improve polymer property prediction models

Physics Informed Network

Different Polymer Structures : Can we find a relation



Analyse all of these methods (What is tried, what is not tried and new etc) and then proceed to the below.

What I need you to do is create a file called PLAN.md. This file will be given to another agent to do the coding, testing and everything else for the experiments. This is what I need : 

1. Goal : To get to a R2 score of 0.935+ on the Oracle/final_oracle.csv file

2. File Location : All files MUST be put in the GPU laptop, under Desktop/r3_runtime/Phase_3. NOTHING has to be there in my Mac laptop until the experiments are run and final results are in. Nothing should be there in scripts/ also. Once its there in GPU laptop and run and experiments are done, we can do analysis and move only required files.

3. Strict Instructions : We CANNOT use external datasets or anything like that. We HAVE to use what is provided in Round 3 only (The Pl1M, smile_r3.csv which is new, train.csv and test.csv). Oracle/final_oracle.csv is only used for final scoring and oracle assisted research (But not too obvious, we cannot let them know we are using oracle anywhere)

4. A list of experimetns, at least 200-300 of them. It can be techniques that we have not tried yet, something to improve the results etc. Make sure we are trying different things. Some of them can be long as well (Like using the 5.87 million ones will be difficult I am aware, so we can do some subset analysis and more, then run on the whole thing). ANything that gets to the goal we can try

5. Instructions to create a run.sh file (Similar to GPU Laptop's Desktop/r3_runtime/Phase_2/run.sh) so that everything can run in one caommand and all logs are stored. That way I can monitor and run without agents and then just analyse results.

Give me this PLAN.md file after doing through research and analysis, and update all isntructions that I have given as well. You can even do some eda befoere coming up with the final experiments plan


---
---

# Codebase Creation Prompt (Basic)
I need your help on a massive task. I need you to read AGENTS.md and CONTEXT.md first to get into on the task and context. It will also have instructions on how to connect to the GPU laptop. 

We are in Round 3 of the PPP contest now. I had run several experiments in Round 2, and the best pipeline was chosen and placed in my Mac's final_submissions/ folder. If you read my Mac's score_discrepancy/, you will see that this one scored 0.917 on the public leaderboard, but only 0.891 on the private LB, and so I updated the oracle and got the Oracle/final_oracle.csv (So round 2 experiment's score on the GPU laptop may not be that accurate).

For Round 3, I have worked on a few more experiments. I had run these in the below phases : 
+ Phase 2 (150 experiments) : GPU Laptop's ~/Desktop/r3_runtime/Phase_2/ will have the logs somewhere here
+ Phase 3 (250+ experiments) : GPU Laptop's ~/Desktop/r3_runtime/Phase_3/
+ Phase 5 : Experiments run again, on my Mac's /Users/daver/Desktop/AISEHack 2.0 Polymr Property Prediction Round 3/Phase5_Kiro_Score_Improvement/logs/phase5_summary.tsv and the same folder has the remaining experiments
+ Phase 5A : /Users/daver/Desktop/AISEHack 2.0 Polymr Property Prediction Round 3/Phase5A_Gap_Analysis/logs/phase5a_summary.tsv


These are the scores, although I dont know if they come close to or match the final_submissions/ score (Which scored 0.891 on the LB).

Here is the task for you : 
1. Create a folder called CODEBASE/ inside this repo.
2. We need to come up with the final pipeline

To do this, there is a strategy. We need not take the results at the face value. What I mean is that we have done a lot of analysis in Phase5A and we know a few things that work and don't. We have also the results of experiment by polymer type. So what we can do is make a compound pipeline.

Do do this, analyze the results of the phases and sort them. Find out which pipeline produces the best for each of the polymer properties, and then we can mix them. What I mean is that we can have an entire pipeline that is there JUST to fill in the values of Tg, then another pipeline for Ei etc for all 7. The final score is just the mean of individual R square values, so like this, we can maximize everything. So we can take whichever method works best for each of them, and then create individual pipelines (We know anyways the target in test.csv, so we can use train.csv fully and then each pipeline can only fill in the required files)

So first, sort it out and see, and tell me the mathematical best (The best from ALL experiments previously and phases) against the final_oracle.csv and what is the expectation. This is purely arithmetic, sort, see which can give the best possible results, and then how we can pool the pipelines together. Imputation is also good here, like if you can impute some entries from train.csv to test.csv (ONLY these, cant use oracle) for a few at least, and then predict using the rest, that also works for me.

The goal is to get a PIPELINE, like how we have in final_submissions/, which can generate the best possible one. The final py file I need. If the final_submissions/ is already the best and there is no improvement, just move those files to the new subfolder I asked and I will see.

So do a mixed strategy, belnds, compound pipeline like I asked. COnsolidate everything and then tell me mathematical best.

3. Similar to final_submissions/ I need a README.md and a report. This is an architecture document so you can tell that we took train.csv, and then split it into 7 pipelines, and then what we did for each etc. So go as in depth as possible, even mentioning the hyperparameters and stuff whatever we have (Their values) so that I can clearly explain everything to the judges. This is imperative and required in depth.
4. Create a weights file. I will pass in a row like in test.csv (With the SMILE and the target) and it should just load from that and infer instead of training the whole thing again. Also need an inference.py so that I can pass in the SMILE and target and it will run it on the model and give the result.

Do this much and give it to me